<?php
include("config.php");
if($thehash == md5($user.$passwort) or $_COOKIE['login'] == true){
	$datei = $_GET['file'];
	$ordner = "./files/".$_GET['dir'];
	$vollername = $ordner.$datei;
	if(file_exists($vollername) == true){
		$filename = sprintf("%s/%s", $ordner, $datei);
		header("Content-Type: application/octet-stream");
		$save_as_name = basename($vollername);
		header("Content-Disposition: attachment; filename=\"$save_as_name\"");
		readfile($filename);
	}else{
		echo "<meta http-equiv='refresh' content='0,URL=javascript:history.back(-1)'>";
	}
}else{
	echo "<meta http-equiv='refresh' content='0,URL=./'>";
}
