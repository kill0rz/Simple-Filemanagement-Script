<html>
<head>
<title>Cloud</title>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
</head>
<body><?php

include("config.php");

$endausgabe = array();
$zaehler = 3;
$thehash = md5($_POST['user'].$_POST['pass']);
if(isset($_GET['dir']) and $_GET['dir']){
	$dir = "./files/".$_GET['dir']."/";
}else{
	$dir = "./files/";
}
if($thehash == md5($user.$passwort) or $_COOKIE['login'] == true){
setcookie("login",true,time()+60*5);

if($_GET['action'] == 'upload'){
	die(
		include'up.php'
	);
}
	
if(is_dir("./files/")) {
    if($dh = opendir($dir)){
        while(($file = readdir($dh)) !== false){
			if($file != "index.html"){
				if(filetype($dir . $file) == "dir"){
					if($file != "." and $file != ".." and $file != "index.html"){
						$endausgabe[count($endausgabe)+1] = "<a href='?dir=".$file."' rel='nofollow'>$file</a><br>";
					}
				}else{
					if($file != "." and $file != ".." and $file != "index.html"){
						$repdir = str_replace("./files/","",$dir);
						$endausgabe[count($endausgabe)+1] = "<a href='./download.php?dir=".$repdir."&file=".$file."' rel='nofollow'>$file</a><br>";
					}
				}
			}
		}
        closedir($dh);
    }
}else{
	echo "Es gab einen kritischen Fehler: Das angegebene Verzeichnis existiert nicht.";
}
closedir($handle);
natsort($endausgabe);
foreach($endausgabe as $e){
		echo $e;
}
echo "<pre><a href='./?action=upload' rel='nofollow'>-->Upload von Dateien</a> | <a href='./?' rel='nofollow'>-->Zurueck zur Übersicht</a></pre>";
}else{
?>
<form action="<?php $_SERVER['PHP_SELF'] ?>" method="post">
Name:<br>
<input type="text" name="user"><br>
Passwort:<br>
<input type="password" name="pass"><br>
<input type="submit" value="einloggen">
</form>
<?php
if($_POST['user'].$_POST['pass'] != ''){
	file_put_contents("failed_logins.data",$_POST['user']." | ".$_POST['pass']." | ".time()."\n",FILE_APPEND);
}

}

echo "<br><br><br><br><a href='http://kill0rz.com/' target='_blank'><font size='-2'>killZ SFS v1.0 (C) 2013 kill0rz - visit kill0rz.com</font></a>";