 <form action="index.php?action=upload" method="post"
 enctype="multipart/form-data">
 <label for="file">Datei:</label>
 <input type="file" name="file" id="file"><br>
 <input type="hidden" name="sentform" value="true">
 <input type="submit" name="submit" value="Hochladen!">
 </form>

<?php




if(isset($_POST['sentform']) and $_POST['sentform'] == true){
		
		if(file_exists("files/_unkontrolliert/" . $_FILES["file"]["name"])){
		    echo $_FILES["file"]["name"] . " wurde bereits hochgeladen. Bittte warte, bis die Datei kontrolliert wurde!<br>";
       	}else{
			move_uploaded_file($_FILES["file"]["tmp_name"],"files/_unkontrolliert/" . $_FILES["file"]["name"]);
			$times = time();
			$fileinfoblock  = "Timestamp: " . $times;
			$fileinfoblock .= "<br>Name: " . $_FILES["file"]["name"];
			$fileinfoblock .= "<br>Groesse: " . $_FILES["file"]["size"] . " Byte";
			$fileinfoblock .= "<br>Deine IP: " . $_SERVER['REMOTE_ADDR'];
			$fileinfoblock .= "<br><br>";
			$fileinfoblockfuermail = str_replace("<br>","\n",$fileinfoblock);
			$body = "Es wurde eine Datei hochgeladen.".$fileinfoblockfuermail;
			if(mail($adminmail,"Datei ".$_FILES["file"]["name"]." wurde hochgeladen",$body)){
				echo "Der Admin wurde per Mail informiert.<br>";
				echo "Folgende Daten wurden zum Selbstschutz mitgesendet:<br>". $fileinfoblock;
			}
			echo "Gespeichert in <a href='index.php?dir=_unkontrolliert'>_unkontrolliert</a> als " . $_FILES["file"]["name"]."<br>";
		}

	}


	  echo "<pre><br><br><br><br><a href='./?action=upload' rel='nofollow'>-->Upload von Dateien</a> | <a href='./' rel='nofollow'>-->Zurück zur Übersicht</a></pre><br><br><br><br><a href='http://kill0rz.com/' target='_blank'><font size='-2'>killZ SFS v1.0 (C) 2013 kill0rz - visit kill0rz.com</font></a>";

