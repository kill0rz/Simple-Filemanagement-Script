<?php  

include("config.php");

$endausgabe = array();
$zaehler = 3;
if(isset($_POST['user']) and isset($_POST['pass'])){
	$thehash = md5($_POST['user'].$_POST['pass']);
}else{
	$thehash = "";
}
if(isset($_GET['dir']) and $_GET['dir']){
	$dir = "./files/".$_GET['dir']."/";
}else{
	$dir = "./files/";
}
if($thehash == md5($user.$passwort) or $_COOKIE['login'] == true){
setcookie("login",true,time()+60*5);
?>
<!DOCTYPE HTML>
<html>
	<head>
		<title>Cloud</title>
		<meta http-equiv="content-type" content="text/html; charset=utf-8" />
		<meta name="description" content="" />
		<meta name="keywords" content="" />
		<link rel="stylesheet" href="css/font/style.css" />
		<script src="js/jquery.min.js"></script>
		<script src="js/skel.min.js"></script>
		<script src="js/skel-panels.min.js"></script>
		<script src="js/init.js"></script>
		<noscript>
			<link rel="stylesheet" href="css/skel-noscript.css" />
			<link rel="stylesheet" href="css/style.css" />
			<link rel="stylesheet" href="css/style-desktop.css" />
			<link rel="stylesheet" href="css/style-wide.css" />
		</noscript>
		<!--[if lte IE 9]><link rel="stylesheet" href="css/ie9.css" /><![endif]-->
		<!--[if lte IE 8]><script src="js/html5shiv.js"></script><link rel="stylesheet" href="css/ie8.css" /><![endif]-->
		<!--[if lte IE 7]><link rel="stylesheet" href="css/ie7.css" /><![endif]-->
	</head>
	
	<body class="left-sidebar">

		<!-- Wrapper -->
			<div id="wrapper">

				<!-- Content -->
					<div id="content">
						<div id="content-inner">
					
							<!-- Post -->
								<article class="is-post is-post-excerpt">
									<header>
										<h2><a href="index.php">Willkommen zur Cloud</a></h2>
										<span class="byline">Kostenlos und für mobile Geräte optimiert!</span>
									</header>

									<p>
<?php

if(isset($_GET['action']) and $_GET['action'] == 'upload'){
	die(
		include'up.php'
	);
}
	
if(is_dir("./files/")) {
    if($dh = opendir($dir)){
        while(($file = readdir($dh)) !== false){
			if($file != "index.html"){
				if(filetype($dir . $file) == "dir"){
					if($file != "." and $file != ".." and $file != "index.html"){
						$endausgabe[count($endausgabe)+1] = "<i class='fa fa-folder'></i>  <a href='index.php?dir=".$file."' rel='nofollow'>$file</a><br>";
					}
				}else{
					if($file != "." and $file != ".." and $file != "index.html"){
						$repdir = str_replace("./files/","",$dir);
						$endausgabe[count($endausgabe)+1] = "<i class='fa fa-download'></i> <a href='download.php?dir=".$repdir."&file=".$file."' rel='nofollow'>$file</a><br>";
					}
				}
			}
		}
        closedir($dh);
    }
}else{
	echo "Es gab einen kritischen Fehler: Das angegebene Verzeichnis existiert nicht.";
}
natsort($endausgabe);
foreach($endausgabe as $e){
		echo $e;
}
?>
									</p>
								</article>
						</div>
					</div>
					
				<!-- Sidebar -->
					<div id="sidebar">
					
						<!-- Logo -->
							<div id="logo">
								<h1><i class="fa fa-cloud"></i> CLOUD</h1>
							</div>
					
						<!-- Nav -->
							<nav id="nav">
								<ul>
									<li class="current_page_item"><a href="index.php"><i class="fa fa-home"></i> Startseite</a></li>
									<li><a href='index.php?action=upload' rel='nofollow'><i class="fa fa-upload"></i> Upload von Dateien</a></li> 
								</ul>
							</nav>
							
						<!-- Text -->
							<section class="is-text-style1">
								<div class="inner">
									<p>
										<strong>CLOUD:</strong> Willkommen zu Deinem einfachen Onlinespeicher!</a>
									</p>
								</div>
							</section>
						<!-- Impressum -->
							<section class="is-text-style1">
								<div class="inner">
									<p>
										<strong>killZ SFS v1.0</strong> - <a href='http://kill0rz.com/' target='_blank'>&copy; 2013 kill0rz - visit kill0rz.com</a>Design by Ragnar
									</p>
								</div>
							</section>
					</div>
							
			</div>

							<?php
}else{
?>
<!DOCTYPE HTML>
<html>
	<head>
		<title>Cloud</title>
		<meta http-equiv="content-type" content="text/html; charset=utf-8" />
		<meta name="description" content="" />
		<meta name="keywords" content="" />
		<link rel="stylesheet" href="css/font/style.css" />
		<script src="js/jquery.min.js"></script>
		<script src="js/skel.min.js"></script>
		<script src="js/skel-panels.min.js"></script>
		<script src="js/init.js"></script>
		<noscript>
			<link rel="stylesheet" href="css/skel-noscript.css" />
			<link rel="stylesheet" href="css/style.css" />
			<link rel="stylesheet" href="css/style-desktop.css" />
			<link rel="stylesheet" href="css/style-wide.css" />
		</noscript>
		<!--[if lte IE 9]><link rel="stylesheet" href="css/ie9.css" /><![endif]-->
		<!--[if lte IE 8]><script src="js/html5shiv.js"></script><link rel="stylesheet" href="css/ie8.css" /><![endif]-->
		<!--[if lte IE 7]><link rel="stylesheet" href="css/ie7.css" /><![endif]-->
	</head>
	
	<body class="left-sidebar">

		<!-- Wrapper -->
			<div id="wrapper">

				<!-- Content -->
					<div id="content">
						<div id="content-inner">
					
							<!-- Post -->
								<article class="is-post is-post-excerpt">
									<header>
										<h2><a href="index.php">Willkommen zur Cloud</a></h2>
										<span class="byline">Kostenlos und für mobile Geräte optimiert!</span>
									</header>
									
								</article>
						</div>
					</div>
					
				<!-- Sidebar -->
					<div id="sidebar">
					
						<!-- Logo -->
							<div id="logo">
								<h1><i class="fa fa-cloud"></i> CLOUD</h1>
							</div>
					
						<!-- Nav -->
							<nav id="nav">
								<ul>
									<li class="current_page_item"><a href="index.php"><i class="fa fa-home"></i> Startseite</a></li>
								</ul>
							</nav>
						<!-- Login -->
							<section class="is-login">
							<form action="<?php $_SERVER['PHP_SELF'] ?>" method="post">
							Name:<br>
							<input type="text" name="user"><br>
							Passwort:<br>
							<input type="password" name="pass"><br><br>
							<input type="submit" value="Anmelden">
							</form>
							</section>
					
						<!-- Text -->
							<section class="is-text-style1">
								<div class="inner">
									<p>
										<strong>CLOUD:</strong> Du musst angemeldet sein um Dateien hochzuladen!
									</p>
								</div>
							</section>
						<!-- Impressum -->
							<section class="is-text-style1">
								<div class="inner">
									<p>
										<strong>killZ SFS v1.0</strong> - <a href='http://kill0rz.com/' target='_blank'>&copy; 2013 kill0rz - visit kill0rz.com</a>
									</p>
								</div>
							</section>
							
					</div>
							
			</div>

<?php
if($_POST['user'].$_POST['pass'] != ''){
	file_put_contents("failed_logins.data",$_POST['user']." | ".$_POST['pass']." | ".time()."\n",FILE_APPEND);
}

}
?>