<?php

/*

	killZ SFS v1.0
	(C) 2013 kill0rz
	for further instructions visit http://blog.kill0rz.com/2013/11/25/download-kill0rz-simple-filemanagement-script/
	
*/

$user = "testuser";

$passwort = "ztestpasswort";

$adminmail = "example@example.com";