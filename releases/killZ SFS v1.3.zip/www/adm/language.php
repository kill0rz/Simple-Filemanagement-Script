<?php

/*

	killZ SFS v1.3
	(C) 2013-2014 kill0rz
	for further instructions visit http://blog.kill0rz.com/2013/11/25/download-kill0rz-simple-filemanagement-script/
	
*/

/*

In dieser Datei stehen alle Sprachvariablen drin, die benutzt werden.

*/

$lang_alterpic = "CLOUD";
$lang_back = "<-- Zur�ck";
$lang_byline = "Untertitel";
$lang_chooseasemester = "Waehle ein Semester:";
$lang_file = "Datei:";
$lang_folderdoesnotexist = "Es gab einen kritischen Fehler: Das angegebene Verzeichnis existiert nicht und konnte es auch nicht erstellen. Wende dich an den Webmaster!";
$lang_freetext1 = "Freitext";
$lang_header = "Willkommen in der Cloud!";
$lang_impressum = "<b>killZ SFS v1.3</b>";
$lang_internalstatisticsdatabase = "Datenbankgr��e: 0 Byte/keine Datenbank verwendet";
$lang_internalstatisticsfiles = "Anzahl aller Dateien hier:";
$lang_internalstatisticsfolders = "Anzahl aller Ordner hier:";
$lang_internalstatisticsheadline = "interne Statistiken:";
$lang_internalstatisticssize = "Gesamtgr��e aller Dateien hier:";
$lang_logout = "Logout";
$lang_mail_body1 = "Es wurde eine Datei hochgeladen.";
$lang_mail_body2 = "Datei";
$lang_mail_body3 = "wurde hochgeladen";
$lang_mail_body4 = "Der Admin wurde per Mail informiert.<br>Folgende Daten wurden zum Selbstschutz mitgesendet:<br>";
$lang_mail_body5 = "Gespeichert in";
$lang_mail_body6 = "als";
$lang_mail_fileinfoblock1 = "Timestamp:";
$lang_mail_fileinfoblock2 = "Name:";
$lang_mail_fileinfoblock3 = "Gr��e:";
$lang_mail_fileinfoblock4 = "Deine IP:";
$lang_mail_fileinfoblock5 = "Semester:";
$lang_name = "Name";
$lang_notusingssl = "Du benutzt eine unverschl�sselte Verbindung!";
$lang_password = "Passwort";
$lang_startpage = "Startseite";
$lang_startseite = "Startseite";
$lang_title = "Cloud";
$lang_update_available = "Es ist ein Update erschienen. Lade es bitte herunter! <a href='http://kill0rz.com/sfs/'>http://kill0rz.com/sfs/</a>";
$lang_upload2 = "Hochladen!";
$lang_upload = "Upload von Dateien";
$lang_upload_error_file_exists = "wurde in diesem Semester bereits hochgeladen. Bittte warte, bis die Datei kontrolliert wurde!<br>";
$lang_uploadheadline = "<strong>UPLOAD:</strong> Hier hast Du die M�glichkeit, Dateien hochzuladen!";
$lang_youareinsemester = "Du befindest dich aktuell im Semester";
$lang_register = "Registrieren";