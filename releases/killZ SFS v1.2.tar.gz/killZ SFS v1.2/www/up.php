<?php

if(isset($_GET['n']) and $_GET['n'] != ''){
	$n = trim($_GET['n']);
}elseif(isset($_POST['n']) and $_POST['n'] != ''){
	$n = trim($_POST['n']);
}else{
	$n = $aktuellessemester;
}

$ns = array(1,2,3,4,5,6);
foreach($ns as $ns){
	if(trim($n) == trim($ns)){
		$n = $ns;
		$ntrue = true;
	}
}	
if(!$ntrue){
	$n = $aktuellessemester;
}

?>
 <section class="is-login">
 <form action="index.php?action=upload" method="post"
 enctype="multipart/form-data">
 <label for="file"><i class="fa fa-file"></i> Datei:</label>
 <input type="file" name="file" id="file"><br><br>
 <input type="hidden" name="sentform" value="true">
 <input type="hidden" name="n" value="<?php echo $n ?>">
 <input type="submit" name="submit" value="Hochladen!">
 </form>
 </section>
 
<?php
if(isset($_POST['sentform']) and $_POST['sentform'] == true){
		
		if(file_exists("./files_semester{$n}/_unkontrolliert/" . $_FILES["file"]["name"])){
		    echo $_FILES["file"]["name"] . " wurde in diesem Semester bereits hochgeladen. Bittte warte, bis die Datei kontrolliert wurde!<br>";
       	}else{
			move_uploaded_file($_FILES["file"]["tmp_name"],"files_semester{$n}/_unkontrolliert/" . $_FILES["file"]["name"]);
			@chmod("files_semester{$n}/_unkontrolliert/" . $_FILES["file"]["name"], 0777 );
			$times = time();
			$fileinfoblock  = "Timestamp: " . $times;
			$fileinfoblock .= "<br>Name: " . $_FILES["file"]["name"];
			$fileinfoblock .= "<br>Groesse: " . $_FILES["file"]["size"] . " Byte";
			$fileinfoblock .= "<br>Deine IP: " . $_SERVER['REMOTE_ADDR'];
			$fileinfoblock .= "<br>Semester: " . $n;
			$fileinfoblock .= "<br><br>";
			$fileinfoblockfuermail = str_replace("<br>","\n",$fileinfoblock);
			$body = "Es wurde eine Datei hochgeladen.".$fileinfoblockfuermail;
			if(mail($adminmail,"Datei ".$_FILES["file"]["name"]." wurde hochgeladen",$body)){
				echo "Der Admin wurde per Mail informiert.<br>";
				echo "Folgende Daten wurden zum Selbstschutz mitgesendet:<br>". $fileinfoblock;
			}
			echo "Gespeichert in <a href='index.php?dir=_unkontrolliert&n={$n}'>_unkontrolliert</a> als " . $_FILES["file"]["name"]."<br>";
		}

	}

?>
 </div>
	</div>
				<!-- Sidebar -->
					<div id="sidebar">
					
						<!-- Logo -->
							<div id="logo">
								<h1><i class="fa fa-cloud"></i> CLOUD</h1>
							</div>
					
						<!-- Nav -->
							<nav id="nav">
								<ul>
									<li class="current_page_item"><a href="./?"><i class="fa fa-home"></i>  Startseite</a></li>
									<li><a href='./?action=upload' rel='nofollow'><i class="fa fa-upload"></i>  Upload von Dateien</a></li> 
								</ul>
							</nav>
							
						<!-- Text -->
							<section class="is-text-style1">
								<div class="inner">
									<p>
										<strong>UPLOAD:</strong> Hier hast Du die Möglichkeit, Dateien hochzuladen!</a>
									</p>
								</div>
							</section>
						<!-- Impressum -->
							<section class="is-text-style1">
								<div class="inner">
									<p>
										powered by<br>
										<b>killZ SFS v1.2</b>
									</p>
								</div>
							</section>
					</div>
